const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

function loadCommands(client) {
    const commandsPath = path.join(__dirname, '../commands');
    const commandFolders = fs.readdirSync(commandsPath);

    for (const folder of commandFolders) {
        const folderPath = path.join(commandsPath, folder);
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));

        for (const file of commandFiles) {
            const filePath = path.join(folderPath, file);
            const command = require(filePath);

            if ('name' in command && 'execute' in command) {
                // Add filepath to command for later reference
                command.filepath = filePath;

                // Create slash command data if not provided
                if (!command.slashCommand && command.name) {
                    command.slashCommand = {
                        name: command.name,
                        description: command.description || 'No description provided',
                        options: command.options || []
                    };

                    // Default slash command execution if not provided
                    command.executeSlash = async (interaction) => {
                        try {
                            await command.execute(interaction, interaction.options.data);
                        } catch (error) {
                            logger.error(`Error executing slash command ${command.name}:`, error);
                            throw error;
                        }
                    };
                }

                client.commands.set(command.name, command);
                logger.info(`Loaded command: ${command.name}`);
            } else {
                logger.warn(`Invalid command file: ${filePath}`);
            }
        }
    }
}

module.exports = { loadCommands };