const { PermissionFlagsBits, SlashCommandBuilder } = require('discord.js');
const logger = require('../../utils/logger');

module.exports = {
    name: 'banir',
    description: 'Bane um membro do servidor',
    usage: '!banir <@usuário/ID> [motivo]',

    // Add slash command data
    slashCommand: new SlashCommandBuilder()
        .setName('banir')
        .setDescription('Bane um membro do servidor')
        .addUserOption(option =>
            option.setName('usuario')
                .setDescription('O usuário que será banido (mencione ou use ID)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('motivo')
                .setDescription('Motivo do banimento')
                .setRequired(false)),

    // Traditional command execution
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return message.reply('Você não tem permissão para banir membros!');
        }

        if (!args.length) {
            return message.reply('Por favor, mencione um membro ou forneça um ID para banir!');
        }

        let member;
        const mentionOrId = args[0];

        // Check if it's a mention or ID
        if (message.mentions.members.size > 0) {
            member = message.mentions.members.first();
        } else {
            try {
                member = await message.guild.members.fetch(mentionOrId);
                if (!member) {
                    return message.reply('Membro não encontrado! Verifique se o ID está correto.');
                }
            } catch (error) {
                return message.reply('ID de usuário inválido!');
            }
        }

        const reason = args.slice(1).join(' ') || 'Nenhum motivo fornecido';

        try {
            await member.ban({ reason });
            logger.info(`${member.user.tag} foi banido por ${message.author.tag} pelo motivo: ${reason}`);
            message.channel.send(`${member.user.tag} foi banido com sucesso`);
        } catch (error) {
            logger.error('Erro ao banir membro:', error);
            message.reply('Falha ao banir o membro.');
        }
    },

    // Slash command execution
    async executeSlash(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return interaction.reply({ content: 'Você não tem permissão para banir membros!', ephemeral: true });
        }

        const user = interaction.options.getUser('usuario');
        const reason = interaction.options.getString('motivo') || 'Nenhum motivo fornecido';

        let member;
        try {
            member = await interaction.guild.members.fetch(user.id);
            if (!member) {
                return interaction.reply({
                    content: 'Membro não encontrado no servidor!',
                    ephemeral: true
                });
            }
        } catch (error) {
            return interaction.reply({
                content: 'Não foi possível encontrar o membro no servidor.',
                ephemeral: true
            });
        }

        try {
            await member.ban({ reason });
            logger.info(`${member.user.tag} foi banido por ${interaction.user.tag} pelo motivo: ${reason}`);
            interaction.reply(`${member.user.tag} foi banido com sucesso pelo motivo: ${reason}`);
        } catch (error) {
            logger.error('Erro ao banir membro:', error);
            interaction.reply({ content: 'Falha ao banir o membro.', ephemeral: true });
        }
    },
};