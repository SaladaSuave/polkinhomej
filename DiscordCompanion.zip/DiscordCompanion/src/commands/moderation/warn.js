
const { PermissionFlagsBits } = require('discord.js');
const logger = require('../../utils/logger');

module.exports = {
    name: 'advertir',
    description: 'Adverte um membro',
    usage: '!advertir <usuário> [motivo]',
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
            return message.reply('Você não tem permissão para advertir membros!');
        }

        const member = message.mentions.members.first();
        if (!member) {
            return message.reply('Por favor, mencione um membro para advertir!');
        }

        const reason = args.slice(1).join(' ') || 'Nenhum motivo fornecido';

        try {
            await message.channel.send(`${member.user.tag} foi advertido pelo motivo: ${reason}`);
            logger.info(`${member.user.tag} foi advertido por ${message.author.tag} pelo motivo: ${reason}`);
            
            try {
                await member.send(`Você foi advertido em ${message.guild.name} pelo motivo: ${reason}`);
            } catch (error) {
                message.channel.send("Não foi possível enviar DM para o usuário.");
            }
        } catch (error) {
            logger.error('Erro ao advertir membro:', error);
            message.reply('Falha ao advertir o membro.');
        }
    },
};
