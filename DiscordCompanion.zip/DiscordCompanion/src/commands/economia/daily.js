const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const { addBalance, getLastDaily, updateLastDaily } = require('../../utils/database');
const logger = require('../../utils/logger');

module.exports = {
    name: 'daily',
    aliases: ['diario'],
    description: 'Recebe sua recompensa a cada 5 minutos',
    usage: '!daily',

    // Add slash command data
    slashCommand: new SlashCommandBuilder()
        .setName('daily')
        .setDescription('Recebe sua recompensa a cada 5 minutos'),

    // Traditional command execution
    execute(message, args) {
        const userId = message.author.id;
        const lastDaily = getLastDaily(userId);
        const now = new Date();

        if (lastDaily) {
            const lastDailyDate = new Date(lastDaily);
            const timeDiff = now - lastDailyDate;
            const minutesDiff = timeDiff / (1000 * 60);

            if (minutesDiff < 5) {
                const timeLeft = Math.ceil(5 - minutesDiff);
                return message.reply(`Você precisa esperar ${timeLeft} minutos para receber novamente!`);
            }
        }

        const amount = 100;
        const newBalance = addBalance(userId, amount);
        updateLastDaily(userId);

        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('💰 Recompensa')
            .setDescription(`Você recebeu **${amount}** TokuCoins!\nSeu novo saldo é: **${newBalance}** TokuCoins`)
            .setTimestamp();

        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} recebeu daily reward de ${amount} TokuCoins`);
    },

    // Slash command execution
    async executeSlash(interaction) {
        const userId = interaction.user.id;
        const lastDaily = getLastDaily(userId);
        const now = new Date();

        if (lastDaily) {
            const lastDailyDate = new Date(lastDaily);
            const timeDiff = now - lastDailyDate;
            const minutesDiff = timeDiff / (1000 * 60);

            if (minutesDiff < 5) {
                const timeLeft = Math.ceil(5 - minutesDiff);
                return interaction.reply({ 
                    content: `Você precisa esperar ${timeLeft} minutos para receber novamente!`,
                    ephemeral: true 
                });
            }
        }

        const amount = 100;
        const newBalance = addBalance(userId, amount);
        updateLastDaily(userId);

        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('💰 Recompensa')
            .setDescription(`Você recebeu **${amount}** TokuCoins!\nSeu novo saldo é: **${newBalance}** TokuCoins`)
            .setTimestamp();

        interaction.reply({ embeds: [embed] });
        logger.info(`${interaction.user.tag} recebeu daily reward de ${amount} TokuCoins`);
    },
};