const { EmbedBuilder } = require('discord.js');
const { getBalance } = require('../../utils/database');

module.exports = {
    name: 'dinheiro',
    aliases: ['money', 'balance'], // Adicionando aliases
    description: 'Mostra seu saldo atual',
    usage: '!dinheiro',
    execute(message, args) {
        const balance = getBalance(message.author.id);

        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('💰 Seu Saldo')
            .setDescription(`${message.author.username}, você tem **${balance}** TokuCoins!`)
            .setTimestamp();

        message.reply({ embeds: [embed] });
    },
};