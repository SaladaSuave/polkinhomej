const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const { getJob, setJob, addJobExperience, getLastWork, updateLastWork, addBalance } = require('../../utils/database');
const { hasBoostRole } = require('../../utils/roles');
const logger = require('../../utils/logger');

const JOBS = {
    'lixeiro': {
        salary: 50,
        description: 'Coleta lixo pela cidade',
        nextJob: 'entregador',
        expRequired: 400
    },
    'entregador': {
        salary: 75,
        description: 'Entrega pacotes e comidas',
        nextJob: 'vendedor',
        expRequired: 800
    },
    'vendedor': {
        salary: 100,
        description: 'Vende produtos em lojas',
        nextJob: 'programador',
        expRequired: 1200
    },
    'programador': {
        salary: 150,
        description: 'Desenvolve software',
        nextJob: null,
        expRequired: null
    }
};

module.exports = {
    name: 'trabalhar',
    aliases: ['work', 'job', 'lista', 'trabalhos'],
    description: 'Sistema de trabalho para ganhar TokuCoins',
    usage: '!trabalhar [iniciar/lista/trabalhos] - Use "lista" ou "trabalhos" para ver empregos disponíveis',

    // Add slash command data
    slashCommand: new SlashCommandBuilder()
        .setName('trabalhar')
        .setDescription('Sistema de trabalho para ganhar TokuCoins')
        .addSubcommand(subcommand =>
            subcommand
                .setName('iniciar')
                .setDescription('Começa a trabalhar para ganhar TokuCoins'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('lista')
                .setDescription('Mostra a lista de empregos disponíveis')),

    // Keep the original execute function
    execute(message, args) {
        const userId = message.author.id;
        const userJob = getJob(userId);

        if (!args.length) {
            // Mostra informações do trabalho atual
            if (!userJob.job) {
                setJob(userId, 'lixeiro'); // Começa como lixeiro
                return showJobList(message, 0);
            }

            const job = JOBS[userJob.job];
            const embed = new EmbedBuilder()
                .setColor(0x0099FF)
                .setTitle('💼 Seu Trabalho')
                .setDescription(`**${userJob.job}**\n💼 ${job.description}`);

            const fields = [
                { name: '💰 Salário', value: `${job.salary} TokuCoins`, inline: true },
                { name: '⭐ Experiência', value: `${userJob.experience} pontos`, inline: true }
            ];

            if (job.nextJob) {
                fields.push({
                    name: '📈 Próxima Promoção',
                    value: `${job.nextJob} (${JOBS[job.nextJob].salary} TokuCoins)\n⭐ Experiência necessária: ${job.expRequired} pontos`,
                    inline: false
                });
            } else {
                fields.push({
                    name: '👑 Cargo Máximo',
                    value: 'Você atingiu o topo da carreira!',
                    inline: false
                });
            }

            embed.addFields(fields)
                .setFooter({ text: 'Use !trabalhar iniciar para trabalhar ou !trabalhar lista para ver a progressão de carreira' });

            return message.reply({ embeds: [embed] });
        }

        const command = args[0].toLowerCase();

        // Lista de trabalhos disponíveis
        if (command === 'lista' || command === 'trabalhos') {
            return showJobList(message, userJob ? userJob.experience : 0);
        }

        if (command === 'iniciar') {
            const lastWork = getLastWork(userId);
            const now = new Date();

            if (lastWork) {
                const lastWorkDate = new Date(lastWork);
                const timeDiff = now - lastWorkDate;
                const minutesDiff = timeDiff / (1000 * 60);

                if (minutesDiff < 15) { // Mudado de 30 para 15 minutos
                    const timeLeft = Math.ceil(15 - minutesDiff); // Atualizado para 15 minutos
                    return message.reply(`Você precisa descansar por mais ${timeLeft} minutos antes de trabalhar novamente!`);
                }
            }

            if (!userJob.job) {
                setJob(userId, 'lixeiro');
            }

            const job = JOBS[userJob.job];
            const earnedExp = Math.floor(Math.random() * 20) + 10;
            let expMultiplier = 1;

            // Check for boost role
            if (hasBoostRole(message.member)) {
                expMultiplier = 2;
            }

            const actualEarnedExp = Math.floor(earnedExp * expMultiplier);
            const newExp = userJob.experience + actualEarnedExp;
            let promotionMessage = '';

            // Verifica se pode ser promovido
            if (job.nextJob && newExp >= job.expRequired) {
                const nextJob = job.nextJob;
                setJob(userId, nextJob);
                promotionMessage = `\n🎉 Parabéns! Você foi promovido para ${nextJob}!`;
            } else {
                addJobExperience(userId, actualEarnedExp);
            }

            addBalance(userId, job.salary);
            updateLastWork(userId);

            const embed = new EmbedBuilder()
                .setColor(0x00FF00)
                .setTitle('💼 Trabalho Concluído!')
                .setDescription(
                    `Você trabalhou duro e ganhou:
                    - ${job.salary} TokuCoins
                    - ${actualEarnedExp} pontos de experiência${expMultiplier > 1 ? ' (2x boost ativo!)' : ''}${promotionMessage}`
                )
                .setTimestamp();

            message.reply({ embeds: [embed] });
            logger.info(`${message.author.tag} trabalhou como ${userJob.job} e ganhou ${job.salary} TokuCoins`);
            return;
        }

        message.reply('Comando inválido! Use `!trabalhar lista` para ver a progressão de carreira ou `!trabalhar iniciar` para trabalhar.');
    },

    // Add slash command execution
    async executeSlash(interaction) {
        const userId = interaction.user.id;
        const userJob = getJob(userId);
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'lista') {
            return showJobList(interaction, userJob ? userJob.experience : 0);
        }

        if (subcommand === 'iniciar') {
            const lastWork = getLastWork(userId);
            const now = new Date();

            if (lastWork) {
                const lastWorkDate = new Date(lastWork);
                const timeDiff = now - lastWorkDate;
                const minutesDiff = timeDiff / (1000 * 60);

                if (minutesDiff < 15) {
                    const timeLeft = Math.ceil(15 - minutesDiff);
                    return interaction.reply({
                        content: `Você precisa descansar por mais ${timeLeft} minutos antes de trabalhar novamente!`,
                        ephemeral: true
                    });
                }
            }

            if (!userJob.job) {
                setJob(userId, 'lixeiro');
            }

            const job = JOBS[userJob.job];
            const earnedExp = Math.floor(Math.random() * 20) + 10;
            let expMultiplier = 1;

            if (hasBoostRole(interaction.member)) {
                expMultiplier = 2;
            }

            const actualEarnedExp = Math.floor(earnedExp * expMultiplier);
            const newExp = userJob.experience + actualEarnedExp;
            let promotionMessage = '';

            if (job.nextJob && newExp >= job.expRequired) {
                const nextJob = job.nextJob;
                setJob(userId, nextJob);
                promotionMessage = `\n🎉 Parabéns! Você foi promovido para ${nextJob}!`;
            } else {
                addJobExperience(userId, actualEarnedExp);
            }

            addBalance(userId, job.salary);
            updateLastWork(userId);

            const embed = new EmbedBuilder()
                .setColor(0x00FF00)
                .setTitle('💼 Trabalho Concluído!')
                .setDescription(
                    `Você trabalhou duro e ganhou:
                    - ${job.salary} TokuCoins
                    - ${actualEarnedExp} pontos de experiência${expMultiplier > 1 ? ' (2x boost ativo!)' : ''}${promotionMessage}`
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
            logger.info(`${interaction.user.tag} trabalhou como ${userJob.job} e ganhou ${job.salary} TokuCoins`);
        }
    }
};

async function showJobList(interactionOrMessage, userExp) {
    const jobList = Object.entries(JOBS).map(([name, info], index) => {
        const isAvailable = name === 'lixeiro' || (info.expRequired && userExp >= info.expRequired);

        return `${isAvailable ? '✅' : '🔒'} **${name}**\n` +
            `💼 ${info.description}\n` +
            `💰 Salário: ${info.salary} TokuCoins\n` +
            (info.nextJob ? `⭐ Experiência para próximo cargo: ${info.expRequired} pontos\n` : '👑 Cargo Final\n');
    }).join('\n');

    const embed = new EmbedBuilder()
        .setColor(0x0099FF)
        .setTitle('🏢 Progressão de Carreira')
        .setDescription(`Sua evolução profissional começa como lixeiro. Conforme você ganha experiência, será promovido automaticamente!\n\n${jobList}`)
        .setFooter({ text: '✅ = Disponível | 🔒 = Bloqueado | Use /trabalhar iniciar para trabalhar' });

    if (interactionOrMessage.reply) {
        return interactionOrMessage.reply({ embeds: [embed] });
    } else {
        return interactionOrMessage.reply({ embeds: [embed] });
    }
}