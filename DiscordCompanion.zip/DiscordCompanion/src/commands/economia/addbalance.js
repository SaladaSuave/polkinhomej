const { PermissionFlagsBits, EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const { addBalance } = require('../../utils/database');
const logger = require('../../utils/logger');

module.exports = {
    name: 'addbalance',
    description: 'Adiciona TokuCoins a um usuário (apenas administradores)',
    usage: '!addbalance <@usuário> <quantidade>',

    // Add slash command data
    slashCommand: new SlashCommandBuilder()
        .setName('addbalance')
        .setDescription('Adiciona TokuCoins a um usuário (apenas administradores)')
        .addUserOption(option =>
            option.setName('usuario')
                .setDescription('O usuário que receberá as TokuCoins')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('quantidade')
                .setDescription('Quantidade de TokuCoins para adicionar')
                .setRequired(true)
                .setMinValue(1)),

    // Traditional command execution
    execute(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply('Você precisa ser administrador para usar este comando!');
        }

        if (args.length < 2) {
            return message.reply('Use: !addbalance <@usuário> <quantidade>');
        }

        const target = message.mentions.users.first();
        if (!target) {
            return message.reply('Por favor, mencione um usuário válido!');
        }

        const amount = parseInt(args[1]);
        if (isNaN(amount) || amount <= 0) {
            return message.reply('Por favor, insira uma quantidade válida de TokuCoins!');
        }

        try {
            const newBalance = addBalance(target.id, amount);

            const embed = new EmbedBuilder()
                .setColor(0x00FF00)
                .setTitle('💰 TokuCoins Adicionadas')
                .setDescription(`${message.author} adicionou **${amount}** TokuCoins para ${target}`)
                .addFields(
                    { name: 'Novo Saldo', value: `${newBalance} TokuCoins`, inline: true }
                )
                .setTimestamp();

            message.reply({ embeds: [embed] });
            logger.info(`${message.author.tag} adicionou ${amount} TokuCoins para ${target.tag}`);
        } catch (error) {
            logger.error('Erro ao adicionar TokuCoins:', error);
            message.reply('Ocorreu um erro ao adicionar as TokuCoins.');
        }
    },

    // Slash command execution
    async executeSlash(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                content: 'Você precisa ser administrador para usar este comando!',
                ephemeral: true
            });
        }

        const target = interaction.options.getUser('usuario');
        const amount = interaction.options.getInteger('quantidade');

        try {
            const newBalance = addBalance(target.id, amount);

            const embed = new EmbedBuilder()
                .setColor(0x00FF00)
                .setTitle('💰 TokuCoins Adicionadas')
                .setDescription(`${interaction.user} adicionou **${amount}** TokuCoins para ${target}`)
                .addFields(
                    { name: 'Novo Saldo', value: `${newBalance} TokuCoins`, inline: true }
                )
                .setTimestamp();

            interaction.reply({ embeds: [embed] });
            logger.info(`${interaction.user.tag} adicionou ${amount} TokuCoins para ${target.tag}`);
        } catch (error) {
            logger.error('Erro ao adicionar TokuCoins:', error);
            interaction.reply({
                content: 'Ocorreu um erro ao adicionar as TokuCoins.',
                ephemeral: true
            });
        }
    },
};