const { EmbedBuilder, PermissionFlagsBits, SlashCommandBuilder } = require('discord.js');
const { getBalance, addBalance } = require('../../utils/database');
const { grantBoostRole, ensureBoostRole, grantVIPRole, ensureVIPRole } = require('../../utils/roles');
const logger = require('../../utils/logger');

const SHOP_ITEMS = {
    'vip': {
        price: 5000,
        description: 'Status VIP no servidor (👑 VIP)',
        grantVIP: true
    },
    'boost': {
        price: 2000,
        description: 'Multiplicador 2x de experiência por 1 hora (🚀 Boost)',
        grantBoost: true
    }
};

module.exports = {
    name: 'loja',
    aliases: ['shop', 'store'],
    description: 'Loja para gastar suas TokuCoins',
    usage: '!loja [comprar <item>]',

    // Add slash command data
    slashCommand: new SlashCommandBuilder()
        .setName('loja')
        .setDescription('Loja para gastar suas TokuCoins')
        .addSubcommand(subcommand =>
            subcommand
                .setName('listar')
                .setDescription('Mostra os itens disponíveis na loja'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('comprar')
                .setDescription('Compra um item da loja')
                .addStringOption(option =>
                    option.setName('item')
                        .setDescription('O item que você deseja comprar')
                        .setRequired(true)
                        .addChoices(
                            { name: 'VIP - 5000 TokuCoins', value: 'vip' },
                            { name: 'Boost - 2000 TokuCoins', value: 'boost' }
                        ))),

    // Traditional command execution
    async execute(message, args) {
        if (!args.length) {
            const itemList = Object.entries(SHOP_ITEMS).map(([name, info]) => 
                `**${name}** - ${info.description} (${info.price} TokuCoins)`
            ).join('\n');

            const embed = new EmbedBuilder()
                .setColor(0x0099FF)
                .setTitle('🛍️ Loja')
                .setDescription(`Use \`!loja comprar <item>\` para comprar um item\n\n${itemList}`)
                .setFooter({ text: 'Mais itens em breve!' });

            return message.reply({ embeds: [embed] });
        }

        if (args[0] === 'comprar') {
            const itemName = args[1]?.toLowerCase();
            if (!itemName || !SHOP_ITEMS[itemName]) {
                return message.reply('Item não encontrado! Use `!loja` para ver a lista de itens disponíveis.');
            }

            const item = SHOP_ITEMS[itemName];
            const userBalance = getBalance(message.author.id);

            if (userBalance < item.price) {
                return message.reply(`Você não tem TokuCoins suficientes! Você precisa de ${item.price} TokuCoins.`);
            }

            // Verificar permissões do bot antes de prosseguir
            const botMember = message.guild.members.me;
            if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
                return message.reply('❌ Não posso conceder o cargo porque não tenho a permissão "Gerenciar Cargos". Peça para um administrador configurar minhas permissões.');
            }

            try {
                let roleCreated = false;
                if (item.grantVIP) {
                    const vipRole = await ensureVIPRole(message.guild);
                    if (!vipRole) {
                        return message.reply('❌ Não foi possível criar o cargo VIP. Verifique se tenho todas as permissões necessárias e se meu cargo está acima do cargo que estou tentando gerenciar.');
                    }
                    roleCreated = true;
                } else if (item.grantBoost) {
                    const boostRole = await ensureBoostRole(message.guild);
                    if (!boostRole) {
                        return message.reply('❌ Não foi possível criar o cargo boost. Verifique se tenho todas as permissões necessárias e se meu cargo está acima do cargo que estou tentando gerenciar.');
                    }
                    roleCreated = true;
                }

                if (!roleCreated) {
                    return message.reply('❌ Ocorreu um erro ao verificar os cargos. Por favor, tente novamente.');
                }

                // Se todas as verificações passaram, prosseguir com a compra
                addBalance(message.author.id, -item.price);

                if (item.grantVIP) {
                    await grantVIPRole(message.member);
                } else if (item.grantBoost) {
                    await grantBoostRole(message.member);
                }

                const embed = new EmbedBuilder()
                    .setColor(0x00FF00)
                    .setTitle('🛍️ Compra Realizada!')
                    .setDescription(`Você comprou **${itemName}** por ${item.price} TokuCoins!`)
                    .addFields(
                        { name: 'Saldo Restante', value: `${userBalance - item.price} TokuCoins`, inline: true }
                    )
                    .setTimestamp();

                message.reply({ embeds: [embed] });
                logger.info(`${message.author.tag} comprou ${itemName} por ${item.price} TokuCoins`);
            } catch (error) {
                logger.error(`Erro ao processar compra de ${itemName} para ${message.author.tag}:`, error);
                message.reply('❌ Ocorreu um erro ao processar sua compra. Por favor, verifique se tenho todas as permissões necessárias e se a hierarquia de cargos está correta.');
                // Reembolsar o usuário se algo der errado
                addBalance(message.author.id, item.price);
            }
        }
    },

    // Slash command execution
    async executeSlash(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'listar') {
            const itemList = Object.entries(SHOP_ITEMS).map(([name, info]) => 
                `**${name}** - ${info.description} (${info.price} TokuCoins)`
            ).join('\n');

            const embed = new EmbedBuilder()
                .setColor(0x0099FF)
                .setTitle('🛍️ Loja')
                .setDescription(`Use \`/loja comprar\` para comprar um item\n\n${itemList}`)
                .setFooter({ text: 'Mais itens em breve!' });

            return interaction.reply({ embeds: [embed] });
        }

        if (subcommand === 'comprar') {
            const itemName = interaction.options.getString('item');
            const item = SHOP_ITEMS[itemName];
            const userBalance = getBalance(interaction.user.id);

            if (userBalance < item.price) {
                return interaction.reply({
                    content: `Você não tem TokuCoins suficientes! Você precisa de ${item.price} TokuCoins.`,
                    ephemeral: true
                });
            }

            const botMember = interaction.guild.members.me;
            if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
                return interaction.reply({
                    content: '❌ Não posso conceder o cargo porque não tenho a permissão "Gerenciar Cargos". Peça para um administrador configurar minhas permissões.',
                    ephemeral: true
                });
            }

            try {
                let roleCreated = false;
                if (item.grantVIP) {
                    const vipRole = await ensureVIPRole(interaction.guild);
                    if (!vipRole) {
                        return interaction.reply({
                            content: '❌ Não foi possível criar o cargo VIP. Verifique as permissões necessárias.',
                            ephemeral: true
                        });
                    }
                    roleCreated = true;
                } else if (item.grantBoost) {
                    const boostRole = await ensureBoostRole(interaction.guild);
                    if (!boostRole) {
                        return interaction.reply({
                            content: '❌ Não foi possível criar o cargo boost. Verifique as permissões necessárias.',
                            ephemeral: true
                        });
                    }
                    roleCreated = true;
                }

                if (!roleCreated) {
                    return interaction.reply({
                        content: '❌ Ocorreu um erro ao verificar os cargos. Por favor, tente novamente.',
                        ephemeral: true
                    });
                }

                addBalance(interaction.user.id, -item.price);

                if (item.grantVIP) {
                    await grantVIPRole(interaction.member);
                } else if (item.grantBoost) {
                    await grantBoostRole(interaction.member);
                }

                const embed = new EmbedBuilder()
                    .setColor(0x00FF00)
                    .setTitle('🛍️ Compra Realizada!')
                    .setDescription(`Você comprou **${itemName}** por ${item.price} TokuCoins!`)
                    .addFields(
                        { name: 'Saldo Restante', value: `${userBalance - item.price} TokuCoins`, inline: true }
                    )
                    .setTimestamp();

                interaction.reply({ embeds: [embed] });
                logger.info(`${interaction.user.tag} comprou ${itemName} por ${item.price} TokuCoins`);
            } catch (error) {
                logger.error(`Erro ao processar compra de ${itemName} para ${interaction.user.tag}:`, error);
                interaction.reply({
                    content: '❌ Ocorreu um erro ao processar sua compra. Verifique as permissões necessárias.',
                    ephemeral: true
                });
                // Reembolsar o usuário se algo der errado
                addBalance(interaction.user.id, item.price);
            }
        }
    }
};