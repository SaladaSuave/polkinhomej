const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const { getBalance, addBalance } = require('../../utils/database');
const logger = require('../../utils/logger');

module.exports = {
    name: 'pagar',
    aliases: ['pay', 'transfer'],
    description: 'Transfere TokuCoins para outro usuário',
    usage: '!pagar <@usuário/ID> <quantidade>',

    // Add slash command data
    slashCommand: new SlashCommandBuilder()
        .setName('pagar')
        .setDescription('Transfere TokuCoins para outro usuário')
        .addIntegerOption(option =>
            option.setName('quantidade')
                .setDescription('Quantidade de TokuCoins para transferir')
                .setRequired(true)
                .setMinValue(1))
        .addUserOption(option =>
            option.setName('usuario')
                .setDescription('O usuário que receberá os TokuCoins (mencione ou use ID)')
                .setRequired(true)),

    // Traditional command execution
    execute(message, args) {
        if (args.length < 2) {
            return message.reply('Use: !pagar <@usuário/ID> <quantidade>');
        }

        let recipient;
        const mentionOrId = args[0];

        // Check if it's a mention or ID
        if (message.mentions.users.size > 0) {
            recipient = message.mentions.users.first();
        } else {
            try {
                recipient = message.client.users.cache.get(mentionOrId);
                if (!recipient) {
                    return message.reply('Usuário não encontrado! Verifique se o ID está correto.');
                }
            } catch (error) {
                return message.reply('ID de usuário inválido!');
            }
        }

        const amount = parseInt(args[1]);
        if (isNaN(amount) || amount <= 0) {
            return message.reply('Por favor, insira uma quantidade válida!');
        }

        const senderBalance = getBalance(message.author.id);
        if (senderBalance < amount) {
            return message.reply('Você não tem TokuCoins suficientes!');
        }

        addBalance(message.author.id, -amount);
        addBalance(recipient.id, amount);

        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('💸 Transferência realizada')
            .setDescription(`${message.author} transferiu **${amount}** TokuCoins para ${recipient}!`)
            .setTimestamp();

        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} transferiu ${amount} TokuCoins para ${recipient.tag}`);
    },

    // Slash command execution
    async executeSlash(interaction) {
        const amount = interaction.options.getInteger('quantidade');
        const recipient = interaction.options.getUser('usuario');

        const senderBalance = getBalance(interaction.user.id);
        if (senderBalance < amount) {
            return interaction.reply({ 
                content: 'Você não tem TokuCoins suficientes!',
                ephemeral: true 
            });
        }

        addBalance(interaction.user.id, -amount);
        addBalance(recipient.id, amount);

        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('💸 Transferência realizada')
            .setDescription(`${interaction.user} transferiu **${amount}** TokuCoins para ${recipient}!`)
            .setTimestamp();

        interaction.reply({ embeds: [embed] });
        logger.info(`${interaction.user.tag} transferiu ${amount} TokuCoins para ${recipient.tag}`);
    }
};