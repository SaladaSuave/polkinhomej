const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const { getTopBalances } = require('../../utils/database');

module.exports = {
    name: 'rank',
    aliases: ['top', 'ranking'],
    description: 'Mostra o ranking dos usuários mais ricos',
    usage: '!rank',

    // Add slash command data
    slashCommand: new SlashCommandBuilder()
        .setName('rank')
        .setDescription('Mostra o ranking dos usuários mais ricos'),

    // Traditional command execution
    async execute(message, args) {
        const topUsers = getTopBalances(10);

        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('🏆 Ranking - Usuários mais ricos')
            .setTimestamp();

        let description = '';
        for (let i = 0; i < topUsers.length; i++) {
            try {
                const user = await message.client.users.fetch(topUsers[i].user_id);
                description += `${i + 1}. ${user.username}: **${topUsers[i].balance}** TokuCoins\n`;
            } catch (error) {
                description += `${i + 1}. ID ${topUsers[i].user_id}: **${topUsers[i].balance}** TokuCoins\n`;
            }
        }

        embed.setDescription(description || 'Nenhum usuário encontrado');
        message.reply({ embeds: [embed] });
    },

    // Slash command execution
    async executeSlash(interaction) {
        const topUsers = getTopBalances(10);

        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('🏆 Ranking - Usuários mais ricos')
            .setTimestamp();

        let description = '';
        for (let i = 0; i < topUsers.length; i++) {
            try {
                const user = await interaction.client.users.fetch(topUsers[i].user_id);
                description += `${i + 1}. ${user.username}: **${topUsers[i].balance}** TokuCoins\n`;
            } catch (error) {
                description += `${i + 1}. ID ${topUsers[i].user_id}: **${topUsers[i].balance}** TokuCoins\n`;
            }
        }

        embed.setDescription(description || 'Nenhum usuário encontrado');
        await interaction.reply({ embeds: [embed] });
    }
};