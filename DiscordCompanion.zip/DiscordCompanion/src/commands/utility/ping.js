
module.exports = {
    name: 'ping',
    description: 'Mostra o ping do bot',
    async execute(message, args) {
        const ferinha = await message.channel.send(` \`🏓 Pong!\` `);
        ferinha.edit(`
        \`💻 Ping do servidor:\` \`${ferinha.createdTimestamp -
            message.createdTimestamp}ms\`
        \`⏰ Ping da API:\` \`${Math.round(
            message.client.ws.ping
        )}ms\``);
    }
};
