const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getBalance, addBalance, getLastSlots, updateLastSlots } = require('../../utils/database');
const logger = require('../../utils/logger');

const cardValues = {
    '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10,
    'J': 10, 'Q': 10, 'K': 10, 'A': 11
};

const suits = ['♠️', '♥️', '♦️', '♣️'];
const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

function createDeck() {
    const deck = [];
    for (const suit of suits) {
        for (const rank of ranks) {
            deck.push({ rank, suit });
        }
    }
    return shuffle(deck);
}

function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function calculateHandValue(hand) {
    let value = 0;
    let aces = 0;

    for (const card of hand) {
        if (card.rank === 'A') {
            aces++;
        } else {
            value += cardValues[card.rank];
        }
    }

    for (let i = 0; i < aces; i++) {
        if (value + 11 <= 21) {
            value += 11;
        } else {
            value += 1;
        }
    }

    return value;
}

function formatHand(hand, hideSecond = false) {
    if (hideSecond) {
        return `${hand[0].rank}${hand[0].suit} | ?️?`;
    }
    return hand.map(card => `${card.rank}${card.suit}`).join(' | ');
}

function createInviteEmbed(challenger, challenged, betAmount) {
    return new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle('🎲 Desafio de Blackjack')
        .setDescription(`${challenger} **apostou ${betAmount} TokuCoins!\nBoa sorte! 🍀**`)
        .setThumbnail(challenger.displayAvatarURL({ dynamic: true }))
        .setImage('https://media1.tenor.com/m/JB5-_RFjOUMAAAAC/crazy-slots-roll.gif')
        .setTimestamp();
}

function createGameEmbed(message, players, betAmount, hideHands = false, gameStatus = '', buttonsDisabled = false) {
    const embed = new EmbedBuilder()
        .setColor(0x0099FF)
        .setTitle('🎲 Blackjack Multiplayer')
        .addFields(
            { name: `${players[0].user.username}`, value: formatHand(players[0].hand, hideHands), inline: true },
            { name: `${players[1].user.username}`, value: formatHand(players[1].hand, hideHands), inline: true },
            { name: 'Aposta', value: `${betAmount} TokuCoins` }
        )
        .setFooter({ text: `Vez de: ${players.find(p => p.isTurn)?.user.username || 'Fim de jogo'}` });

    if (gameStatus) {
        embed.setDescription(gameStatus);
    } else {
        embed.setDescription(`Turno atual: ${players.find(p => p.isTurn)?.user.username}`);
    }

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('hit')
                .setLabel('Pedir Carta')
                .setEmoji('👊')
                .setStyle(ButtonStyle.Primary)
                .setDisabled(buttonsDisabled),
            new ButtonBuilder()
                .setCustomId('stand')
                .setLabel('Parar')
                .setEmoji('✋')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(buttonsDisabled)
        );

    return { embed, row };
}

module.exports = {
    name: 'blackjack',
    aliases: ['bj'],
    description: 'Jogue Blackjack sozinho ou contra outro jogador',
    usage: '!blackjack <valor da aposta> | !blackjack all | !blackjack <@usuário> <valor da aposta> | !blackjack <@usuário> all',
    async execute(message, args) {
        if (!args.length) {
            return message.reply('Use: !blackjack <valor da aposta> ou !blackjack <@usuário> <valor da aposta>. Use "all" para apostar tudo!');
        }

        const isSinglePlayer = !message.mentions.users.first();
        const betArg = isSinglePlayer ? args[0] : args[1];
        const userBalance = getBalance(message.author.id);
        let betAmount;

        if (betArg?.toLowerCase() === 'all') {
            if (userBalance <= 0) {
                return message.reply('Você não tem TokuCoins para apostar!');
            }
            betAmount = userBalance;
        } else {
            betAmount = parseInt(betArg);
            if (isNaN(betAmount) || betAmount <= 0) {
                return message.reply('Por favor, forneça um valor válido para apostar!');
            }
        }

        if (userBalance < betAmount) {
            return message.reply(`Você não tem TokuCoins suficientes! Seu saldo atual é de ${userBalance} TokuCoins.`);
        }

        if (isSinglePlayer) {
            startSinglePlayerGame(message, betAmount);
        } else {
            const challenged = message.mentions.users.first();

            if (challenged.id === message.author.id) {
                return message.reply('Você não pode desafiar a si mesmo!');
            }

            if (challenged.bot) {
                return message.reply('Você não pode desafiar um bot!');
            }

            const challengedBalance = getBalance(challenged.id);
            if (challengedBalance < betAmount) {
                return message.reply(`${challenged.username} não tem TokuCoins suficientes! O saldo dele(a) é de ${challengedBalance} TokuCoins.`);
            }

            startMultiplayerGame(message, challenged, betAmount);
        }
    }
};

async function startSinglePlayerGame(message, betAmount) {
    const deck = createDeck();
    const botHand = [deck.pop(), deck.pop()];
    const playerHand = [deck.pop(), deck.pop()];

    addBalance(message.author.id, -betAmount);

    const welcomeEmbed = {
        color: 0x5865F2,
        title: '🎲 Hora do Blackjack!',
        description: `${message.author} **apostou ${betAmount} TokuCoins!\nBoa sorte! 🍀**`,
        thumbnail: {
            url: message.author.displayAvatarURL({ dynamic: true })
        },
        image: {
            url: 'https://media1.tenor.com/m/JB5-_RFjOUMAAAAC/crazy-slots-roll.gif'
        },
        timestamp: new Date()
    };

    const welcomeMessage = await message.channel.send({ embeds: [welcomeEmbed] });

    setTimeout(async () => {
        await welcomeMessage.delete().catch(console.error);

        const gameEmbed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('🎲 Blackjack')
            .addFields(
                { name: 'Bot', value: `${botHand[0].rank}${botHand[0].suit} | ?️?`, inline: true },
                { name: message.author.username, value: formatHand(playerHand), inline: true },
                { name: 'Aposta', value: `${betAmount} TokuCoins` }
            );

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('hit')
                    .setLabel('Pedir Carta')
                    .setEmoji('👊')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('stand')
                    .setLabel('Parar')
                    .setEmoji('✋')
                    .setStyle(ButtonStyle.Secondary)
            );

        const gameMessage = await message.channel.send({
            embeds: [gameEmbed],
            components: [row]
        });

        const filter = i => {
            return ['hit', 'stand'].includes(i.customId) && i.user.id === message.author.id;
        };

        const collector = gameMessage.createMessageComponentCollector({
            filter,
            time: 60000
        });

        collector.on('collect', async (interaction) => {
            await interaction.deferUpdate();

            if (interaction.customId === 'hit') {
                playerHand.push(deck.pop());
                const playerValue = calculateHandValue(playerHand);

                if (playerValue > 21) {
                    collector.stop('bust');
                }

                gameEmbed.setFields(
                    { name: 'Bot', value: `${botHand[0].rank}${botHand[0].suit} | ?️?`, inline: true },
                    { name: message.author.username, value: formatHand(playerHand), inline: true },
                    { name: 'Aposta', value: `${betAmount} TokuCoins` }
                );

                await gameMessage.edit({
                    embeds: [gameEmbed],
                    components: playerValue > 21 ? [] : [row]
                });
            } else if (interaction.customId === 'stand') {
                collector.stop('stand');
            }
        });

        collector.on('end', async (_, reason) => {
            const playerValue = calculateHandValue(playerHand);
            let botValue = calculateHandValue(botHand);

            while (botValue < 17 && reason === 'stand') {
                botHand.push(deck.pop());
                botValue = calculateHandValue(botHand);
            }

            let result = '';
            let won = false;

            if (reason === 'bust') {
                result = `Você estourou com ${playerValue} pontos!`;
            } else if (botValue > 21) {
                result = `Bot estourou com ${botValue} pontos! Você venceu!`;
                won = true;
            } else if (playerValue > botValue) {
                result = `Você venceu com ${playerValue} pontos contra ${botValue}!`;
                won = true;
            } else if (botValue > playerValue) {
                result = `Bot venceu com ${botValue} pontos contra ${playerValue}!`;
            } else {
                result = `Empate! Ambos fizeram ${playerValue} pontos!`;
                addBalance(message.author.id, betAmount);
            }

            if (won) {
                addBalance(message.author.id, betAmount * 2);
            }

            const finalEmbed = new EmbedBuilder()
                .setColor(won ? 0x00ff00 : (result.includes('Empate') ? 0xffff00 : 0xff0000))
                .setTitle(won ? '🎉 Vitória!' : (result.includes('Empate') ? '🤝 Empate!' : '😔 Derrota!'))
                .setDescription(result)
                .addFields(
                    { name: 'Bot', value: formatHand(botHand), inline: true },
                    { name: message.author.username, value: formatHand(playerHand), inline: true },
                    { name: 'Aposta', value: `${betAmount} TokuCoins` }
                )
                .setImage(won
                    ? 'https://media1.tenor.com/m/nBWlYPbKxzwAAAAC/anime-happy.gif'
                    : (result.includes('Empate')
                        ? 'https://media1.tenor.com/m/8RN1T9BpqGIAAAAC/handshake-deal.gif'
                        : 'https://media1.tenor.com/m/cZAW8f5L1O0AAAAC/sad-anime.gif'))
                .setTimestamp();


            await gameMessage.edit({
                embeds: [finalEmbed],
                components: []
            });

            logger.info(`Blackjack single player: ${message.author.tag} ${won ? 'venceu' : (result.includes('Empate') ? 'empatou' : 'perdeu')} - Aposta: ${betAmount} TokuCoins`);
        });
    }, 7000);
}

async function startMultiplayerGame(message, challenged, betAmount) {
    const inviteRow = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('accept')
                .setLabel('Aceitar')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('decline')
                .setLabel('Recusar')
                .setStyle(ButtonStyle.Danger)
        );

    const inviteMessage = await message.channel.send({
        embeds: [createInviteEmbed(message.author, challenged, betAmount)],
        components: [inviteRow]
    });

    const filter = i => {
        return ['accept', 'decline'].includes(i.customId) && i.user.id === challenged.id;
    };

    try {
        const response = await inviteMessage.awaitMessageComponents({ filter, time: 30000 });

        if (response.customId === 'decline') {
            await inviteMessage.edit({
                embeds: [createInviteEmbed(message.author, challenged, betAmount)
                    .setDescription('❌ Desafio recusado!')],
                components: []
            });
            return;
        }

        await response.deferUpdate();
        addBalance(message.author.id, -betAmount);
        addBalance(challenged.id, -betAmount);

        const deck = createDeck();
        const players = [
            {
                user: message.author,
                hand: [deck.pop(), deck.pop()],
                isTurn: true,
                isStanding: false
            },
            {
                user: challenged,
                hand: [deck.pop(), deck.pop()],
                isTurn: false,
                isStanding: false
            }
        ];

        const { embed, row } = createGameEmbed(message, players, betAmount);
        const gameMessage = await message.channel.send({ embeds: [embed], components: [row] });

        const gameFilter = i => {
            const currentPlayer = players.find(p => p.isTurn);
            return ['hit', 'stand'].includes(i.customId) && i.user.id === currentPlayer.user.id;
        };

        const collector = gameMessage.createMessageComponentCollector({ filter: gameFilter, time: 120000 });

        const welcomeEmbed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('🎲 Hora do Blackjack!')
            .setDescription(`${message.author} **apostou ${betAmount} TokuCoins!\nBoa sorte! 🍀**`)
            .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
            .setImage('https://media1.tenor.com/m/JB5-_RFjOUMAAAAC/crazy-slots-roll.gif')
            .setTimestamp();

        const welcomeMessage = await message.channel.send({ embeds: [welcomeEmbed] });

        setTimeout(async () => {
            await welcomeMessage.delete().catch(console.error);
            collector.on('collect', async (interaction) => {
                await interaction.deferUpdate();
                const currentPlayer = players.find(p => p.isTurn);

                if (interaction.customId === 'hit') {
                    currentPlayer.hand.push(deck.pop());
                    const handValue = calculateHandValue(currentPlayer.hand);

                    if (handValue > 21) {
                        currentPlayer.isStanding = true;
                        const otherPlayer = players.find(p => p !== currentPlayer);
                        otherPlayer.isTurn = true;
                        currentPlayer.isTurn = false;

                        if (otherPlayer.isStanding) {
                            collector.stop('gameover');
                        }
                    }

                    const { embed, row } = createGameEmbed(message, players, betAmount);
                    await gameMessage.edit({ embeds: [embed], components: [row] });
                } else if (interaction.customId === 'stand') {
                    currentPlayer.isStanding = true;
                    const otherPlayer = players.find(p => p !== currentPlayer);

                    if (otherPlayer.isStanding) {
                        collector.stop('gameover');
                    } else {
                        currentPlayer.isTurn = false;
                        otherPlayer.isTurn = true;
                        const { embed, row } = createGameEmbed(message, players, betAmount);
                        await gameMessage.edit({ embeds: [embed], components: [row] });
                    }
                }
            });

            collector.on('end', async (_, reason) => {
                const player1Value = calculateHandValue(players[0].hand);
                const player2Value = calculateHandValue(players[1].hand);
                let result = '';
                let winner = null;

                if (player1Value > 21 && player2Value > 21) {
                    result = 'Empate! Ambos estouraram!';
                    addBalance(players[0].user.id, betAmount);
                    addBalance(players[1].user.id, betAmount);
                } else if (player1Value > 21) {
                    result = `${players[1].user.username} venceu! ${players[0].user.username} estourou!`;
                    winner = players[1].user;
                    addBalance(winner.id, betAmount * 2);
                } else if (player2Value > 21) {
                    result = `${players[0].user.username} venceu! ${players[1].user.username} estourou!`;
                    winner = players[0].user;
                    addBalance(winner.id, betAmount * 2);
                } else if (player1Value > player2Value) {
                    result = `${players[0].user.username} venceu com ${player1Value} pontos contra ${player2Value}!`;
                    winner = players[0].user;
                    addBalance(winner.id, betAmount * 2);
                } else if (player2Value > player1Value) {
                    result = `${players[1].user.username} venceu com ${player2Value} pontos contra ${player1Value}!`;
                    winner = players[1].user;
                    addBalance(winner.id, betAmount * 2);
                } else {
                    result = `Empate! Ambos fizeram ${player1Value} pontos!`;
                    addBalance(players[0].user.id, betAmount);
                    addBalance(players[1].user.id, betAmount);
                }

                const embed = new EmbedBuilder()
                    .setColor(result.includes('venceu') ? 0x00ff00 : 0xff0000)
                    .setTitle(result.includes('venceu') ? '🎉 Vitória!' : (result.includes('Empate') ? '🤝 Empate!' : '😔 Derrota!'))
                    .setDescription(result)
                    .setImage(result.includes('venceu')
                        ? 'https://media1.tenor.com/m/nBWlYPbKxzwAAAAC/anime-happy.gif'
                        : (result.includes('Empate')
                            ? 'https://media1.tenor.com/m/8RN1T9BpqGIAAAAC/handshake-deal.gif'
                            : 'https://media1.tenor.com/m/cZAW8f5L1O0AAAAC/sad-anime.gif'))
                    .setFooter({ text: `Jogadores: ${players[0].user.username} vs ${players[1].user.username}` })
                    .setTimestamp();

                await gameMessage.edit({ embeds: [embed], components: [] });
                logger.info(`Blackjack multiplayer: ${winner ? winner.tag + ' venceu' : 'empate'} - Aposta: ${betAmount} TokuCoins`);
            });
        }, 7000);
    } catch (error) {
        if (error.code === 'INTERACTION_COLLECTOR_ERROR') {
            await inviteMessage.edit({
                embeds: [createInviteEmbed(message.author, challenged, betAmount)
                    .setDescription('⏰ Tempo esgotado!')],
                components: []
            });
        } else {
            logger.error('Erro no jogo de blackjack:', error);
            message.channel.send('Ocorreu um erro durante o jogo.');
        }
    }
}