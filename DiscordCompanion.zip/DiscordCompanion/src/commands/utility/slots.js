const { Slots } = require('discord-gamecord');
const { getBalance, addBalance, getLastSlots, updateLastSlots } = require('../../utils/database');
const logger = require('../../utils/logger');

module.exports = {
    name: 'slots',
    description: 'Jogue os slots e tente a sorte! (5x o valor em caso de vitória)',
    usage: '!slots <valor da aposta> | !slots all',
    execute: async (message, args) => {
        const lastSlots = getLastSlots(message.author.id);
        const now = new Date();

        if (lastSlots) {
            const lastSlotsDate = new Date(lastSlots);
            const timeDiff = now - lastSlotsDate;
            const minutesDiff = timeDiff / (1000 * 60);

            if (minutesDiff < 1) {
                const timeLeft = Math.ceil(60 - (timeDiff / 1000));
                return message.reply(`Você precisa esperar ${timeLeft} segundos para jogar novamente!`);
            }
        }

        if (!args[0]) {
            return message.reply('Por favor, forneça um valor para apostar ou use "all" para apostar tudo. Exemplo: !slots 100');
        }

        const userBalance = getBalance(message.author.id);
        let betAmount;

        if (args[0].toLowerCase() === 'all') {
            if (userBalance <= 0) {
                return message.reply('Você não tem TokuCoins para apostar!');
            }
            betAmount = userBalance;
        } else {
            betAmount = parseInt(args[0]);
            if (isNaN(betAmount) || betAmount <= 0) {
                return message.reply('Por favor, forneça um valor válido para apostar!');
            }

            if (userBalance < betAmount) {
                return message.reply(`Você não tem TokuCoins suficientes! Seu saldo atual é de ${userBalance} TokuCoins.`);
            }
        }

        updateLastSlots(message.author.id);
        addBalance(message.author.id, -betAmount);

        const welcomeEmbed = {
            color: 0x5865F2,
            title: '🎰 Hora do Caça-Níquel!',
            description: `${message.author} **apostou ${betAmount} TokuCoins!\nBoa sorte! 🍀**`,
            thumbnail: {
                url: message.author.displayAvatarURL({ dynamic: true })
            },
            image: {
                url: 'https://media1.tenor.com/m/JB5-_RFjOUMAAAAC/crazy-slots-roll.gif'
            },
            timestamp: new Date()
        };

        const welcomeMessage = await message.channel.send({ embeds: [welcomeEmbed] });

        setTimeout(async () => {
            await welcomeMessage.delete().catch(console.error);

            const Game = new Slots({
                message: message,
                isSlashGame: false,
                embed: {
                    title: 'Caça Níquel',
                    color: '#5865F2'
                },
                slots: ['🍇', '🍊', '🍋', '🍌']
            });

            Game.startGame();
            Game.on('gameOver', result => {
                let prizeAmount = 0;
                if (result.result === 'win') {
                    prizeAmount = betAmount * 5; // Multiplicador 5x
                    addBalance(message.author.id, prizeAmount);
                }

                const embed = {
                    color: result.result === 'win' ? 0x00ff00 : 0xff0000,
                    title: result.result === 'win' ? '🎉 Vitória!' : '😔 Derrota!',
                    description: result.result === 'win' 
                        ? `Parabéns! Você ganhou ${prizeAmount} TokuCoins! (5x)\nSeu novo saldo é: ${getBalance(message.author.id)} TokuCoins` 
                        : `Que pena! Você perdeu ${betAmount} TokuCoins.\nSeu novo saldo é: ${getBalance(message.author.id)} TokuCoins`,
                    image: {
                        url: result.result === 'win'
                            ? 'https://media1.tenor.com/m/nBWlYPbKxzwAAAAC/anime-happy.gif'
                            : 'https://media1.tenor.com/m/cZAW8f5L1O0AAAAC/sad-anime.gif'
                    },
                    footer: {
                        text: `Jogador: ${message.author.username}`
                    },
                    timestamp: new Date()
                };

                message.channel.send({ embeds: [embed] });
                logger.info(`${message.author.tag} jogou slots: ${result.result === 'win' ? 'ganhou' : 'perdeu'} ${result.result === 'win' ? prizeAmount : betAmount} TokuCoins`);
            });
        }, 7000);
    }
};