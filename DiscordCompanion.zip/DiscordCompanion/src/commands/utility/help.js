const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const path = require('path');

module.exports = {
    name: 'ajuda',
    aliases: ['help', 'support'],
    description: 'Mostra todos os comandos disponíveis',
    usage: '!ajuda [comando]',

    // Add slash command data
    slashCommand: new SlashCommandBuilder()
        .setName('ajuda')
        .setDescription('Mostra todos os comandos disponíveis')
        .addStringOption(option =>
            option.setName('comando')
                .setDescription('Nome do comando específico para obter mais informações')
                .setRequired(false)),

    // Traditional command execution
    async execute(message, args) {
        const { commands } = message.client;

        // Se um comando específico foi fornecido
        if (args.length) {
            const commandName = args[0].toLowerCase();
            const command = commands.get(commandName) || 
                           commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

            if (!command) {
                return message.reply('Esse comando não existe!');
            }

            const aliasesText = command.aliases ? `\nAlternativas: ${command.aliases.join(', ')}` : '';

            const embed = new EmbedBuilder()
                .setColor(0x0099FF)
                .setTitle(`Comando: ${command.name}`)
                .setDescription(aliasesText)
                .addFields(
                    { name: '📝 Descrição', value: command.description },
                    { name: '🔍 Uso', value: command.usage || 'Nenhum uso fornecido' }
                )
                .setFooter({ text: 'Use !ajuda para ver todos os comandos' })
                .setTimestamp();

            return message.reply({ embeds: [embed] });
        }

        // Organizar comandos por categoria baseado na estrutura de diretórios
        const categories = new Map();

        for (const [name, command] of commands) {
            const commandPath = require.cache[require.resolve(command.filepath)]?.filename;
            if (!commandPath) continue;

            const category = path.basename(path.dirname(commandPath));

            const categoryMap = {
                'economia': { emoji: '💰', name: 'Economia' },
                'moderation': { emoji: '🛡️', name: 'Moderação' },
                'utility': { emoji: '🔧', name: 'Utilidades' }
            };

            const categoryInfo = categoryMap[category] || { emoji: '📁', name: category };

            if (!categories.has(category)) {
                categories.set(category, {
                    commands: [],
                    emoji: categoryInfo.emoji,
                    name: categoryInfo.name
                });
            }

            categories.get(category).commands.push(command);
        }

        // Create the initial embed
        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('📚 Central de Comandos')
            .setDescription('Use os botões abaixo para navegar entre as categorias.')
            .setThumbnail(message.client.user.displayAvatarURL())
            .setFooter({ text: 'Use !ajuda <comando> ou /ajuda comando:<nome> para mais detalhes sobre um comando específico' });

        // Create navigation buttons
        const row = new ActionRowBuilder();

        for (const [category, info] of categories) {
            row.addComponents(
                new ButtonBuilder()
                    .setCustomId(category)
                    .setLabel(info.name)
                    .setEmoji(info.emoji)
                    .setStyle(ButtonStyle.Primary)
            );
        }

        // Function to update embed with category commands
        function updateEmbed(category) {
            const categoryInfo = categories.get(category);
            const commandsList = categoryInfo.commands
                .map(cmd => {
                    const aliases = cmd.aliases ? ` (${cmd.aliases.join(', ')})` : '';
                    return `\`${cmd.name}\`${aliases}: ${cmd.description}`;
                })
                .join('\n');

            embed.setTitle(`${categoryInfo.emoji} ${categoryInfo.name}`)
                .setDescription(commandsList || 'Nenhum comando nesta categoria.');

            return embed;
        }

        // Send initial message with buttons
        const firstCategory = categories.keys().next().value;
        const helpMessage = await message.reply({
            embeds: [updateEmbed(firstCategory)],
            components: [row]
        });

        // Create interaction collector
        const collector = helpMessage.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            time: 60000
        });

        // Handle button interactions
        collector.on('collect', async interaction => {
            await interaction.update({
                embeds: [updateEmbed(interaction.customId)],
                components: [row]
            });
        });

        // When collector expires, disable buttons
        collector.on('end', () => {
            row.components.forEach(button => button.setDisabled(true));
            helpMessage.edit({ components: [row] }).catch(() => {});
        });
    },

    // Slash command execution
    async executeSlash(interaction) {
        const { commands } = interaction.client;
        const commandName = interaction.options.getString('comando');

        if (commandName) {
            const command = commands.get(commandName) || 
                           commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

            if (!command) {
                return interaction.reply({ content: 'Esse comando não existe!', ephemeral: true });
            }

            const aliasesText = command.aliases ? `\nAlternativas: ${command.aliases.join(', ')}` : '';

            const embed = new EmbedBuilder()
                .setColor(0x0099FF)
                .setTitle(`Comando: ${command.name}`)
                .setDescription(aliasesText)
                .addFields(
                    { name: '📝 Descrição', value: command.description },
                    { name: '🔍 Uso', value: command.usage || 'Nenhum uso fornecido' }
                )
                .setFooter({ text: 'Use /ajuda para ver todos os comandos' })
                .setTimestamp();

            return interaction.reply({ embeds: [embed], ephemeral: true });
        }

        //this section is almost identical to the execute function, adapted for interaction
        const categories = new Map();

        for (const [name, command] of commands) {
            const commandPath = require.cache[require.resolve(command.filepath)]?.filename;
            if (!commandPath) continue;

            const category = path.basename(path.dirname(commandPath));

            const categoryMap = {
                'economia': { emoji: '💰', name: 'Economia' },
                'moderation': { emoji: '🛡️', name: 'Moderação' },
                'utility': { emoji: '🔧', name: 'Utilidades' }
            };

            const categoryInfo = categoryMap[category] || { emoji: '📁', name: category };

            if (!categories.has(category)) {
                categories.set(category, {
                    commands: [],
                    emoji: categoryInfo.emoji,
                    name: categoryInfo.name
                });
            }

            categories.get(category).commands.push(command);
        }

        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('📚 Central de Comandos')
            .setDescription('Use os botões abaixo para navegar entre as categorias.')
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({ text: 'Use !ajuda <comando> ou /ajuda comando:<nome> para mais detalhes sobre um comando específico' });

        const row = new ActionRowBuilder();

        for (const [category, info] of categories) {
            row.addComponents(
                new ButtonBuilder()
                    .setCustomId(category)
                    .setLabel(info.name)
                    .setEmoji(info.emoji)
                    .setStyle(ButtonStyle.Primary)
            );
        }

        function updateEmbed(category) {
            const categoryInfo = categories.get(category);
            const commandsList = categoryInfo.commands
                .map(cmd => {
                    const aliases = cmd.aliases ? ` (${cmd.aliases.join(', ')})` : '';
                    return `\`${cmd.name}\`${aliases}: ${cmd.description}`;
                })
                .join('\n');

            embed.setTitle(`${categoryInfo.emoji} ${categoryInfo.name}`)
                .setDescription(commandsList || 'Nenhum comando nesta categoria.');

            return embed;
        }

        const firstCategory = categories.keys().next().value;
        const helpMessage = await interaction.reply({
            embeds: [updateEmbed(firstCategory)],
            components: [row],
            fetchReply: true
        });

        const collector = helpMessage.createMessageComponentCollector({
            filter: i => i.user.id === interaction.user.id,
            time: 60000
        });

        collector.on('collect', async i => {
            await i.update({
                embeds: [updateEmbed(i.customId)],
                components: [row]
            });
        });

        collector.on('end', () => {
            row.components.forEach(button => button.setDisabled(true));
            interaction.editReply({ components: [row] }).catch(() => {});
        });
    }
};