const { PermissionFlagsBits, SlashCommandBuilder } = require('discord.js');
const logger = require('../../utils/logger');

module.exports = {
    name: 'setavatar',
    description: 'Muda o avatar do bot',
    usage: '!setavatar <URL da imagem>',

    // Add slash command data
    slashCommand: new SlashCommandBuilder()
        .setName('setavatar')
        .setDescription('Muda o avatar do bot')
        .addStringOption(option =>
            option.setName('url')
                .setDescription('URL da nova imagem de avatar')
                .setRequired(true)),

    // Traditional command execution
    async execute(message, args) {
        // Verificar se o usuário tem permissão de administrador
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply('Você precisa ser administrador para mudar o avatar do bot!');
        }

        // Verificar se foi fornecida uma URL
        const avatarUrl = args[0] || message.attachments.first()?.url;
        if (!avatarUrl) {
            return message.reply('Por favor, forneça uma URL de imagem ou anexe uma imagem!');
        }

        try {
            // Tentar mudar o avatar
            await message.client.user.setAvatar(avatarUrl);
            message.reply('Avatar atualizado com sucesso! ✅');
            logger.info(`Avatar do bot atualizado por ${message.author.tag}`);
        } catch (error) {
            logger.error('Erro ao atualizar avatar:', error);
            message.reply('❌ Ocorreu um erro ao atualizar o avatar. Verifique se a URL é válida e se é uma imagem.');
        }
    },

    // Slash command execution
    async executeSlash(interaction) {
        // Verificar se o usuário tem permissão de administrador
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                content: 'Você precisa ser administrador para mudar o avatar do bot!',
                ephemeral: true
            });
        }

        const avatarUrl = interaction.options.getString('url');

        try {
            // Tentar mudar o avatar
            await interaction.client.user.setAvatar(avatarUrl);
            interaction.reply('Avatar atualizado com sucesso! ✅');
            logger.info(`Avatar do bot atualizado por ${interaction.user.tag}`);
        } catch (error) {
            logger.error('Erro ao atualizar avatar:', error);
            interaction.reply({
                content: '❌ Ocorreu um erro ao atualizar o avatar. Verifique se a URL é válida e se é uma imagem.',
                ephemeral: true
            });
        }
    }
};
