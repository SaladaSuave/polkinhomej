const SQLite = require('better-sqlite3');
const path = require('path');
const logger = require('./logger');

const db = new SQLite(path.join(__dirname, '../../economia.db'));

// Inicializar banco de dados
db.exec(`
    CREATE TABLE IF NOT EXISTS economia (
        user_id TEXT PRIMARY KEY,
        balance INTEGER DEFAULT 0,
        last_daily TIMESTAMP,
        last_slots TIMESTAMP,
        job TEXT DEFAULT NULL,
        job_experience INTEGER DEFAULT 0,
        last_work TIMESTAMP,
        last_crime TIMESTAMP,
        last_investment TIMESTAMP,
        investment_amount INTEGER DEFAULT 0
    )
`);

// Adicionar novas colunas se não existirem
const newColumns = [
    'job TEXT DEFAULT NULL',
    'job_experience INTEGER DEFAULT 0',
    'last_work TIMESTAMP',
    'last_crime TIMESTAMP',
    'last_investment TIMESTAMP',
    'investment_amount INTEGER DEFAULT 0'
];

newColumns.forEach(column => {
    try {
        const [columnName] = column.split(' ');
        db.exec(`ALTER TABLE economia ADD COLUMN ${column}`);
    } catch (error) {
        if (!error.message.includes('duplicate column name')) {
            logger.error(`Erro ao adicionar coluna ${columnName}:`, error);
        }
    }
});

function getBalance(userId) {
    const user = db.prepare('SELECT balance FROM economia WHERE user_id = ?').get(userId);
    return user ? user.balance : 0;
}

function setBalance(userId, amount) {
    try {
        const stmt = db.prepare('INSERT OR REPLACE INTO economia (user_id, balance, last_daily) VALUES (?, ?, (SELECT last_daily FROM economia WHERE user_id = ?))');
        stmt.run(userId, amount, userId);
        logger.info(`Balance updated for user ${userId}: ${amount}`);
    } catch (error) {
        logger.error(`Error updating balance for user ${userId}:`, error);
        throw error;
    }
}

function addBalance(userId, amount) {
    try {
        const currentBalance = getBalance(userId);
        const newBalance = currentBalance + amount;

        const stmt = db.prepare(`
            INSERT INTO economia (user_id, balance, last_daily)
            VALUES (?, ?, COALESCE((SELECT last_daily FROM economia WHERE user_id = ?), NULL))
            ON CONFLICT(user_id) DO UPDATE SET balance = ?
        `);

        stmt.run(userId, newBalance, userId, newBalance);
        logger.info(`Added ${amount} to user ${userId}. New balance: ${newBalance}`);
        return newBalance;
    } catch (error) {
        logger.error(`Error adding balance for user ${userId}:`, error);
        throw error;
    }
}

function getLastDaily(userId) {
    const user = db.prepare('SELECT last_daily FROM economia WHERE user_id = ?').get(userId);
    return user ? user.last_daily : null;
}

function updateLastDaily(userId) {
    try {
        const stmt = db.prepare(`
            INSERT INTO economia (user_id, balance, last_daily)
            VALUES (?, COALESCE((SELECT balance FROM economia WHERE user_id = ?), 0), CURRENT_TIMESTAMP)
            ON CONFLICT(user_id) DO UPDATE SET last_daily = CURRENT_TIMESTAMP
        `);
        stmt.run(userId, userId);
        logger.info(`Updated last_daily for user ${userId}`);
    } catch (error) {
        logger.error(`Error updating last_daily for user ${userId}:`, error);
        throw error;
    }
}

function getLastSlots(userId) {
    const user = db.prepare('SELECT last_slots FROM economia WHERE user_id = ?').get(userId);
    return user ? user.last_slots : null;
}

function updateLastSlots(userId) {
    try {
        const stmt = db.prepare(`
            INSERT INTO economia (user_id, balance, last_slots)
            VALUES (?, COALESCE((SELECT balance FROM economia WHERE user_id = ?), 0), CURRENT_TIMESTAMP)
            ON CONFLICT(user_id) DO UPDATE SET last_slots = CURRENT_TIMESTAMP
        `);
        stmt.run(userId, userId);
        logger.info(`Updated last_slots for user ${userId}`);
    } catch (error) {
        logger.error(`Error updating last_slots for user ${userId}:`, error);
        throw error;
    }
}

function getTopBalances(limit = 10) {
    try {
        return db.prepare('SELECT * FROM economia ORDER BY balance DESC LIMIT ?').all(limit);
    } catch (error) {
        logger.error('Error getting top balances:', error);
        throw error;
    }
}

function getJob(userId) {
    const user = db.prepare('SELECT job, job_experience FROM economia WHERE user_id = ?').get(userId);
    return user ? { job: user.job, experience: user.job_experience } : { job: null, experience: 0 };
}

function setJob(userId, job) {
    try {
        const stmt = db.prepare(`
            INSERT INTO economia (user_id, job, job_experience)
            VALUES (?, ?, 0)
            ON CONFLICT(user_id) DO UPDATE SET job = ?, job_experience = 0
        `);
        stmt.run(userId, job, job);
        logger.info(`Job updated for user ${userId}: ${job}`);
    } catch (error) {
        logger.error(`Error updating job for user ${userId}:`, error);
        throw error;
    }
}

function addJobExperience(userId, amount) {
    try {
        const stmt = db.prepare(`
            UPDATE economia 
            SET job_experience = COALESCE(job_experience, 0) + ?
            WHERE user_id = ?
        `);
        stmt.run(amount, userId);
        logger.info(`Added ${amount} job experience to user ${userId}`);
    } catch (error) {
        logger.error(`Error adding job experience for user ${userId}:`, error);
        throw error;
    }
}

function getLastWork(userId) {
    const user = db.prepare('SELECT last_work FROM economia WHERE user_id = ?').get(userId);
    return user ? user.last_work : null;
}

function updateLastWork(userId) {
    try {
        const stmt = db.prepare(`
            INSERT INTO economia (user_id, last_work)
            VALUES (?, CURRENT_TIMESTAMP)
            ON CONFLICT(user_id) DO UPDATE SET last_work = CURRENT_TIMESTAMP
        `);
        stmt.run(userId);
        logger.info(`Updated last_work for user ${userId}`);
    } catch (error) {
        logger.error(`Error updating last_work for user ${userId}:`, error);
        throw error;
    }
}

module.exports = {
    getBalance,
    setBalance,
    addBalance,
    getLastDaily,
    updateLastDaily,
    getTopBalances,
    getLastSlots,
    updateLastSlots,
    getJob,
    setJob,
    addJobExperience,
    getLastWork,
    updateLastWork
};