const { PermissionFlagsBits } = require('discord.js');
const logger = require('./logger');

let boostRoleId = null;
let vipRoleId = null;

async function ensureBoostRole(guild) {
    try {
        const botMember = guild.members.me;
        if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
            logger.error(`Bot não tem permissão para gerenciar cargos em ${guild.name}`);
            return null;
        }

        logger.info(`Iniciando verificação do cargo boost em ${guild.name}`);
        logger.info(`Posição do cargo do bot: ${botMember.roles.highest.position}`);

        let boostRole = guild.roles.cache.find(role => role.name === '🚀 Boost');

        if (boostRole) {
            logger.info(`Encontrado cargo boost existente: ${boostRole.name} (ID: ${boostRole.id})`);
            if (botMember.roles.highest.position <= boostRole.position) {
                logger.error(`O cargo do bot (${botMember.roles.highest.name}) está abaixo do cargo boost na hierarquia`);
                return null;
            }
            boostRoleId = boostRole.id;
            return boostRole;
        }

        logger.info(`Criando novo cargo boost em ${guild.name}`);
        try {
            const newRole = await guild.roles.create({
                name: '🚀 Boost',
                color: '#FF73FA',
                reason: 'Cargo de boost para multiplicador de experiência',
                permissions: [],
                hoist: true,
                mentionable: true,
                position: botMember.roles.highest.position - 1
            });

            logger.info(`Cargo boost criado com sucesso. ID: ${newRole.id}, Posição: ${newRole.position}`);
            boostRoleId = newRole.id;
            return newRole;
        } catch (error) {
            logger.error(`Erro ao criar cargo boost em ${guild.name}:`, error);
            return null;
        }
    } catch (error) {
        logger.error(`Erro ao gerenciar cargo boost em ${guild.name}:`, error);
        return null;
    }
}

async function ensureVIPRole(guild) {
    try {
        const botMember = guild.members.me;
        if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
            logger.error(`Bot não tem permissão para gerenciar cargos em ${guild.name}`);
            return null;
        }

        logger.info(`Iniciando verificação do cargo VIP em ${guild.name}`);
        logger.info(`Posição do cargo do bot: ${botMember.roles.highest.position}`);

        let vipRole = guild.roles.cache.find(role => role.name === '👑 VIP');

        if (vipRole) {
            logger.info(`Encontrado cargo VIP existente: ${vipRole.name} (ID: ${vipRole.id})`);
            if (botMember.roles.highest.position <= vipRole.position) {
                logger.error(`O cargo do bot (${botMember.roles.highest.name}) está abaixo do cargo VIP na hierarquia`);
                return null;
            }
            vipRoleId = vipRole.id;
            return vipRole;
        }

        logger.info(`Criando novo cargo VIP em ${guild.name}`);
        try {
            const newRole = await guild.roles.create({
                name: '👑 VIP',
                color: '#FFD700',
                reason: 'Cargo VIP para membros especiais',
                permissions: [],
                hoist: true,
                mentionable: true,
                position: botMember.roles.highest.position - 1
            });

            logger.info(`Cargo VIP criado com sucesso. ID: ${newRole.id}, Posição: ${newRole.position}`);
            vipRoleId = newRole.id;
            return newRole;
        } catch (error) {
            logger.error(`Erro ao criar cargo VIP em ${guild.name}:`, error);
            return null;
        }
    } catch (error) {
        logger.error(`Erro ao gerenciar cargo VIP em ${guild.name}:`, error);
        return null;
    }
}

async function grantVIPRole(member) {
    try {
        const bot = member.guild.members.me;
        logger.info(`Tentando conceder cargo VIP para ${member.user.tag}`);

        if (!bot.permissions.has(PermissionFlagsBits.ManageRoles)) {
            logger.error(`Bot não tem permissão para gerenciar cargos em ${member.guild.name}`);
            throw new Error('Bot não tem permissão para gerenciar cargos');
        }

        const role = await ensureVIPRole(member.guild);
        if (!role) {
            logger.error('Não foi possível criar ou encontrar o cargo VIP');
            throw new Error('Não foi possível criar ou encontrar o cargo VIP');
        }

        if (bot.roles.highest.position <= role.position) {
            logger.error('Bot não tem permissão para adicionar este cargo (posição hierárquica inferior)');
            throw new Error('Bot não tem permissão hierárquica para adicionar este cargo');
        }

        if (!member.roles.cache.has(role.id)) {
            await member.roles.add(role);
            logger.info(`Cargo VIP concedido para ${member.user.tag}`);
        }
    } catch (error) {
        logger.error(`Erro ao conceder cargo VIP para ${member.user.tag}:`, error);
        throw error;
    }
}

function hasBoostRole(member) {
    if (!boostRoleId) return false;
    return member.roles.cache.has(boostRoleId);
}

async function grantBoostRole(member) {
    try {
        const bot = member.guild.members.me;
        logger.info(`Tentando conceder cargo boost para ${member.user.tag}`);

        if (!bot.permissions.has(PermissionFlagsBits.ManageRoles)) {
            logger.error(`Bot não tem permissão para gerenciar cargos em ${member.guild.name}`);
            throw new Error('Bot não tem permissão para gerenciar cargos');
        }

        const role = await ensureBoostRole(member.guild);
        if (!role) {
            logger.error('Não foi possível criar ou encontrar o cargo de boost');
            throw new Error('Não foi possível criar ou encontrar o cargo de boost');
        }

        if (bot.roles.highest.position <= role.position) {
            logger.error('Bot não tem permissão para adicionar este cargo (posição hierárquica inferior)');
            throw new Error('Bot não tem permissão hierárquica para adicionar este cargo');
        }

        if (!member.roles.cache.has(role.id)) {
            await member.roles.add(role);
            logger.info(`Cargo boost concedido para ${member.user.tag}`);
        }
    } catch (error) {
        logger.error(`Erro ao conceder cargo boost para ${member.user.tag}:`, error);
        throw error;
    }
}

module.exports = {
    ensureBoostRole,
    ensureVIPRole,
    hasBoostRole,
    grantBoostRole,
    grantVIPRole
};