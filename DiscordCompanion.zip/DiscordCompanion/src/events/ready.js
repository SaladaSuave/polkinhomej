const logger = require('../utils/logger');
const { ensureBoostRole, ensureVIPRole } = require('../utils/roles');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        logger.info(`Logged in as ${client.user.tag}`);

        // Set activity
        client.user.setActivity('!ajuda', { type: 'WATCHING' });

        // Verificar e criar cargos em todos os servidores
        for (const guild of client.guilds.cache.values()) {
            try {
                logger.info(`Verificando cargos no servidor: ${guild.name}`);

                // Verificar permissões do bot
                const botMember = guild.members.me;
                if (!botMember.permissions.has('ManageRoles')) {
                    logger.error(`Bot não tem permissão para gerenciar cargos em ${guild.name}`);
                    continue;
                }

                // Verificar cargo boost
                const boostRole = await ensureBoostRole(guild);
                if (boostRole) {
                    logger.info(`Cargo boost verificado com sucesso em ${guild.name}`);
                } else {
                    logger.error(`Não foi possível criar/verificar o cargo boost em ${guild.name}`);
                }

                // Verificar cargo VIP
                const vipRole = await ensureVIPRole(guild);
                if (vipRole) {
                    logger.info(`Cargo VIP verificado com sucesso em ${guild.name}`);
                } else {
                    logger.error(`Não foi possível criar/verificar o cargo VIP em ${guild.name}`);
                }
            } catch (error) {
                logger.error(`Erro ao verificar cargos no servidor ${guild.name}:`, error);
            }
        }
    },
};