const logger = require('../utils/logger');

module.exports = {
    name: 'messageCreate',
    execute(message) {
        if (message.author.bot) return;

        const prefix = '!';
        if (!message.content.startsWith(prefix)) return;

        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();

        const command = message.client.commands.get(commandName) ||
                       message.client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

        if (!command) return;

        try {
            command.execute(message, args);
        } catch (error) {
            logger.error('Error executing command:', error);
            message.reply('There was an error executing that command!');
        }
    },
};