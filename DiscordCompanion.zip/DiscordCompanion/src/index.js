require('dotenv').config();
const { Client, GatewayIntentBits, Collection, EmbedBuilder, ActivityType, REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const logger = require('./utils/logger');
const commandHandler = require('./handlers/commandHandler');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildMessageReactions
    ]
});

client.commands = new Collection();
client.slashCommands = new Collection();

// Initialize the invite cache
const invites = {};

// Load events
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
    const event = require(path.join(eventsPath, file));
    if (event.once) {
        client.once(event.name, (...args) => event.execute(...args));
    } else {
        client.on(event.name, (...args) => event.execute(...args));
    }
}

// Load commands and register slash commands
async function registerCommands() {
    const commands = [];
    await commandHandler.loadCommands(client);

    for (const [name, command] of client.commands) {
        if (command.slashCommand) {
            commands.push(command.slashCommand);
            client.slashCommands.set(name, command);
        }
    }

    try {
        const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
        logger.info('Started refreshing application (/) commands.');

        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: commands },
        );

        logger.info('Successfully reloaded application (/) commands.');
    } catch (error) {
        logger.error('Error refreshing slash commands:', error);
    }
}

// Handle slash commands
client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    const command = client.slashCommands.get(interaction.commandName);
    if (!command) return;

    try {
        await command.executeSlash(interaction);
    } catch (error) {
        logger.error('Error executing slash command:', error);
        const errorMessage = 'Ocorreu um erro ao executar este comando!';
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp({ content: errorMessage, ephemeral: true });
        } else {
            await interaction.reply({ content: errorMessage, ephemeral: true });
        }
    }
});

// Responder menções ao bot
client.on('messageCreate', msg => {
    if (msg.author.bot) return;
    if (msg.channel.type === 'DM') return msg.reply('> __:pleading_face:-**Não Respondo Dm**__\n> __:space_invader:-**Sou Apenas Um Bot!**__');

    if (msg.content === `<@${client.user.id}>` || msg.content === `<@!${client.user.id}>`) {
        const embed1 = new EmbedBuilder()
            .setTitle(`Olá Pessoal!`)
            .setColor('Random')
            .setDescription(`
> :smiley:  » Meu nome é **${client.user.username}** e a minha função é ajudar vocês!
> :grey_exclamation: » Meu prefixo é '!'.
> :grey_question: » Use **!ajuda** ou **/ajuda** para ver meus comandos.
            `)
            .setFooter({ text: 'Bot Testes' });

        msg.channel.send({ embeds: [embed1] });
    }
});

// Atividades do bot
client.on('ready', async () => {
    let activities = [
        `Atualmente em: ${client.guilds.cache.size} Servidores.`,
        `Digite !help ou /help para saber dos meus comandos!`,
        'Tokugawa tomando banho',
        '"Ta olhando o quê, ô pastel?! Cara feia pra mim é fome!"',
        '"Você é grande, mas não é dois, eu sou pequeno, mas não sou metade!"',
        '"Não conheci o outro mundo por querer!"',
        '"Tô na área, se derrubar é pênalti!"'
    ];
    let i = 0;

    setInterval(() => {
        client.user.setActivity(activities[i++ % activities.length], {
            type: ActivityType.Watching
        });
    }, 15000);

    await registerCommands();
    logger.info(`Logged in as ${client.user.tag}`);
});

// Error handling
process.on('unhandledRejection', error => {
    logger.error('Unhandled promise rejection:', error);
});

client.on('error', error => {
    logger.error('Discord client error:', error);
});

// Login
client.login(process.env.DISCORD_TOKEN);